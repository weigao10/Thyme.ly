// module.exports = {
//   apiKey: 
//   authDomain: 
//   databaseURL: 
//   projectId: 
//   storageBucket: 
//   messagingSenderId: 
//   clientId: 
//   clientSecret: 
//   bundleId: 
//   redirectURI:
// };
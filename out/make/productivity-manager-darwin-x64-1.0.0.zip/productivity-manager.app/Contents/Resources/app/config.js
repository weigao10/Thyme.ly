module.exports = {
  apiKey: "AIzaSyCgnEDGbIF_B7NCsWxIbLcYdUNXc4LWOiE",
  authDomain: "thymely-cd776.firebaseapp.com",
  databaseURL: "https://thymely-cd776.firebaseio.com",
  projectId: "thymely-cd776",
  storageBucket: "thymely-cd776.appspot.com",
  messagingSenderId: "79209900610", 
  clientId: '79209900610-ddvq73mdc5vu6ja54prt49alsr4hjimf.apps.googleusercontent.com',
  clientSecret: 'k_8tkP7BhI1gsNbHvRqZrTAx',
  bundleId: 'thyme.ly',
  redirectURI: 'com.googleusercontent.apps.79209900610-ddvq73mdc5vu6ja54prt49alsr4hjimf'
};
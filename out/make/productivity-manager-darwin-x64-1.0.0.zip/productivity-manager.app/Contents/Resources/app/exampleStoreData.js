let temp = {
  activities: {
    neutral: [
      {
        spurts: [
          {
            startTime: "May 15th 2018, 7:02:25 pm",
            endTime: "May 15th 2018, 7:02:32 pm"
          },
          {
            startTime: "May 15th 2018, 7:02:32 pm",
            endTime: "May 15th 2018, 7:02:34 pm"
          }
        ],
        id: 1,
        app: "Electron",
        title:
          "Developer Tools - file:///Users/weigao/Documents/Programming%20files/HRNYC14/Projects/productivity-manager/react-client/dist/index.html",
        duration: 9,
        productivity: "neutral"
      }
    ],
    productive: [],
    distracting: [],
    nextId: 2
  },
  preferences: { trackedApps: ["Google Chrome", "Firefox", "Safari"] }
};
